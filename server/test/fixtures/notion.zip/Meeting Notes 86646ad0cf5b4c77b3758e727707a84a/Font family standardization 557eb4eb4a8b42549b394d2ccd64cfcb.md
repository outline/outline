# Font family standardization

Created: April 21, 2022 8:45 PM
Last Edited Time: April 21, 2022 8:45 PM
Participants: Anonymous, Anonymous
Type: Design Systems

# Goals

- Settle on a single font family for use in the app (there are currently 3)
- Update design system to use new font

# Discussion Items

- How should we divide the design system work?
- Rough time estimate?
- Any potential blockers?

# Action Items

- [ ]  Jen to provide an estimate for design system updates by EOW
- [ ]  Leslie to meet with engineering and share our plans