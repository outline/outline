# Example sub page

In Notion, pages can contain sub pages. It's a great way to organize things without messy folders!

To go back, click the link at the top 👆