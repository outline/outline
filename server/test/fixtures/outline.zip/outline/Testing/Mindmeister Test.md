# Mindmeister Test

sdfsdf


[https://www.mindmeister.com/maps/public_map_shell/326377934/paper-digital-or-online-mind-mapping](https://www.mindmeister.com/maps/public_map_shell/326377934/paper-digital-or-online-mind-mapping)


[https://www.mindmeister.com/1657688615?t=FmwOLvpi4G](https://www.mindmeister.com/1657688615?t=FmwOLvpi4G)


