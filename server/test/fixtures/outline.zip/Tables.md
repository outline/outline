# Tables

## Smartphones

| **Phone** | **Manufacturer** | **Stock** | **Price** |
|:--- |:--- |:--- | ---:|
| iPhone X | Apple | In Stock | $999 |
| P30 | Huawei | Out of Stock | $799 |
| Pixel 3 | Google | In Stock | $799 |
| Galaxy S10 | Samsung | In Stock | $900 |
| Galaxy Note 9 | Samsung | Out of Stock | $800 |