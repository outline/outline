# Get Started

👋 Welcome! This is a private page for you to play May 4, 2019 around with. 

[Untitled](Get%20Started%20723c6ce1473e40b9beebe9f3711c0ca3/Untitled%20Database%20d1d49ff9051d4af9b1298c9056c294b2.csv)

Give these things a try:

- [x]  Create an account
- [ ]  Add a new line and insert something
    
    ![Get%20Started%20723c6ce1473e40b9beebe9f3711c0ca3/plus-menu.gif](Get%20Started%20723c6ce1473e40b9beebe9f3711c0ca3/plus-menu.gif)
    
- [ ]  Drag the **⋮⋮** button on the left of this to-do to reorder
- [ ]  Right-click and delete something
- [ ]  Type '/' for slash commands
- [ ]  [Keyboard shortcuts](https://www.notion.so/Learn-the-shortcuts-66e28cec810548c3a4061513126766b0)
- [ ]  Create subpages inside a page
    
    [Example sub page](Get%20Started%20723c6ce1473e40b9beebe9f3711c0ca3/Example%20sub%20page%204e3c9cede4924e10a3d9f78317eeb7ef.md)
    

Have a question? Click the help button on the bottom and message us!