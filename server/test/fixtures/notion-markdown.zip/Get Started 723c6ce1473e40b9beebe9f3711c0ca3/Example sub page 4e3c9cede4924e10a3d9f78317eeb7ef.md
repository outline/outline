# Example sub page

In Notion, pages can contain sub pages. It's a great way to organize things without messy folders!

To go back, click the link at the top 👆

![Screen Shot 2022-04-21 at 2.23.26 PM.png](Example%20sub%20page%204e3c9cede4924e10a3d9f78317eeb7ef/Screen_Shot_2022-04-21_at_2.23.26_PM.png)

image above?