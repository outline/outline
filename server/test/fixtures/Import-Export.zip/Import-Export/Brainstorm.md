# Brainstorm

## Things to do

- [ ] !!Add a thing!!
- [ ] Add notes in [Meeting Notes](./Brainstorm/Meeting%20Notes.md) of the last week all hands.
- [ ] See If we can update the table in [Tables](./Brainstorm/Tables.md)


