# Code Testing


```sql
output=$(aws s3 sync .* s3://welld-all-yaml-files --exclude ".git/*" --exclude ".gitignore") &&
```


updated.




[https://docs.google.com/document/d/1zkEMfbDh9q4aE8IUbHBa_Y7z8RvRT9GPy1peDz7CoJY/edit#heading=h.qy04dd1ioasn](https://docs.google.com/document/d/1zkEMfbDh9q4aE8IUbHBa_Y7z8RvRT9GPy1peDz7CoJY/edit#heading=h.qy04dd1ioasn)


