# My first document

Hello from the API 👋

This is a test [backlink](/doc/testing-doc-3-V7CLxhb0Xj)

This is a test link to [Test Doc](./Test%20Doc.md)

This is a test link to myself [My first document](/doc/my-first-document-NTU3G1Vbin)